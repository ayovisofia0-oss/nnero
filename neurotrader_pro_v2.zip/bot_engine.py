"""
NEUROTRADER PRO — Motor de Señales Premium
Estrategia: Soporte/Resistencia + EMA50 + Segundo Toque + MFM>=55 + Estocástico
Mercado: Solo REAL | Sin horario fijo | Vencimiento: 1 minuto
"""
import time
import logging
import json as _json
import os as _os
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import pytz
from collections import defaultdict

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

ecuador = pytz.timezone("America/Guayaquil")

# ─────────────────────────────────────────────
# CONSTANTES GLOBALES
# ─────────────────────────────────────────────
VENCIMIENTO_MINUTOS        = 1
MAX_CONCURRENT_TRADES      = 2       # máx 2 ops simultáneas si scores muy similares
VENTANA_ENTRADA_INICIO_SEG = 57      # ventana de entrada: segundos 57-03
VENTANA_ENTRADA_FIN_SEG    = 3
PAUSA_ESCANEO_SEG          = 5       # escanear todos los activos cada 5 segundos
PAUSA_EJECUCION_SEG        = 0.5     # revisar ventana de entrada cada 500ms
RIESGO_AUTO_PCT            = 0.03    # 3% del balance para modo automático
MIN_SCORE_PREMIUM          = 80      # Score mínimo — solo señales de alta confianza
UMBRAL_DOBLE_OP            = 3       # Diferencia máxima de score para ejecutar 2ª op
MFI_MINIMO_CALL            = 45      # MFI mínimo para CALL
MFI_MAXIMO_PUT             = 55      # MFI máximo para PUT
STOCH_SOBREVENTA           = 55      # Estocástico ≤ 55 para CALL
STOCH_SOBRECOMPRA          = 45      # Estocástico ≥ 45 para PUT
MIN_TOQUES_SR              = 2       # Mínimo de toques al nivel S/R
SR_ATR_TOLERANCIA          = 2.5     # Tolerancia de zona S/R en múltiplos de ATR (más estricto)
EMA50_TOLERANCIA_PCT       = 0.0015  # 0.15% tolerancia en EMA50 — filtro duro con banda pequeña
SEÑAL_EXPIRY_SEG           = 55      # Señales válidas máximo 55 segundos (< 1 vela)

ACTIVOS_PERMITIDOS = {
    'EURUSD', 'GBPUSD', 'USDJPY', 'USDCAD', 'XAUUSD',
    'GBPJPY', 'EURJPY', 'AUDUSD', 'NZDUSD', 'EURGBP',
    'USDCHF', 'EURAUD', 'GBPCAD', 'AUDJPY',
}

# ─────────────────────────────────────────────
# SISTEMA DE LICENCIAS
# ─────────────────────────────────────────────
LICENCIAS_FILE = "licencias.json"


def _cargar_licencias() -> dict:
    if _os.path.exists(LICENCIAS_FILE):
        try:
            with open(LICENCIAS_FILE, 'r', encoding='utf-8') as f:
                return _json.load(f)
        except Exception:
            pass
    return {}


def validar_licencia(codigo: str, email: str = None) -> tuple:
    codigo = codigo.strip().upper() if codigo else ""
    if not codigo:
        return False, "Código de licencia requerido"
    licencias = _cargar_licencias()
    if not licencias:
        return False, "No hay licencias registradas. Contacte al administrador."
    if codigo not in licencias:
        return False, f"Código '{codigo}' no válido"
    lic = licencias[codigo]
    if not lic.get('active', True):
        return False, "Licencia desactivada. Contacte al administrador."
    expires = lic.get('expires')
    if expires:
        try:
            exp_date = datetime.fromisoformat(expires)
            if 'T' not in expires and ':' not in expires:
                exp_date = exp_date.replace(hour=23, minute=59, second=59)
            if datetime.now() > exp_date:
                return False, f"Licencia expirada el {expires[:10]}"
        except Exception:
            pass
    lic_email = lic.get('email', '').strip().lower()
    if lic_email and email:
        if email.strip().lower() != lic_email:
            return False, "Este código no corresponde al correo ingresado"
    plan = lic.get('plan', '')
    plan_txt = {
        'semanal': 'Plan Semanal',
        'mensual': 'Plan Mensual',
        'vitalicio': 'Plan Vitalicio'
    }.get(plan, 'acceso completo')
    return True, f"Licencia válida — {plan_txt}"


def crear_licencia(codigo: str, descripcion: str = '', expires: str = None) -> bool:
    licencias = _cargar_licencias()
    licencias[codigo.strip().upper()] = {
        'active':      True,
        'descripcion': descripcion,
        'expires':     expires,
        'creado':      datetime.now().isoformat()[:19],
    }
    try:
        with open(LICENCIAS_FILE, 'w', encoding='utf-8') as f:
            _json.dump(licencias, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False


# ─────────────────────────────────────────────
# HELPERS DE SÍMBOLO
# ─────────────────────────────────────────────

def _limpiar_simbolo(asset: str) -> str:
    """Normaliza el símbolo al nombre base sin sufijos (-OP, OTC, etc.)."""
    a = str(asset or '').upper().strip()
    for suf in ('-OTC', ' OTC', '_OTC', '-OP', '_OP', '-op', '_op'):
        a = a.replace(suf.upper(), '')
    a = a.replace('/', '').replace('-', '').replace('_', '').replace(' ', '')
    return a[:6]


def _es_activo_permitido(asset: str) -> bool:
    return _limpiar_simbolo(asset) in ACTIVOS_PERMITIDOS


def _simbolo_candle(asset: str) -> str:
    """Retorna el símbolo limpio que usa get_candles() de iqoptionapi."""
    return _limpiar_simbolo(asset)


# ─────────────────────────────────────────────
# ESTADO DEL BOT
# ─────────────────────────────────────────────

class BotState:
    def __init__(self):
        self.running = False
        self.logs = []
        self.trades = []
        self.active_trades: list = []
        self.saldo = 0.0
        self.saldo_inicial = 0.0
        self.api = None
        self.tipo_cuenta = "PRACTICE"
        # Gestión de riesgo
        self.modo_riesgo = "automatico"   # "automatico" | "fijo"
        self.monto_fijo = 1.0
        self.monto = 1.0
        # Stats
        self.stats = {
            'total': 0,
            'ganadas': 0,
            'perdidas': 0,
            'devueltas': 0,
            'profit': 0.0,
        }
        self.activos_disponibles = []
        self.señal_actual = None
        self.señales_pendientes: list = []
        self._señales_ts: float = 0.0   # timestamp de cuándo se generaron las señales
        self._ventana_ejecutada: bool = False  # evitar doble ejecución en la misma ventana
        self.scan_progreso = 0
        self.scan_total = 0
        self._email = ""
        self._password = ""
        self._ultimo_refresh_activos = 0
        self.diagnostico = {
            'estado': 'Esperando conexión',
            'ultimo_lote': 'Sin escaneo todavía',
            'mejor_candidato': None,
            'ultimo_bloqueo': 'Ninguno',
            'ultima_ejecucion': 'Ninguna',
            'eventos': [],
            'ultimo_analisis': {},
        }

    def _calcular_monto(self) -> float:
        if self.modo_riesgo == "automatico":
            return max(round(self.saldo * RIESGO_AUTO_PCT, 2), 0.50)
        return max(round(float(self.monto_fijo), 2), 0.50)

    def add_log(self, msg, nivel="INFO"):
        ts = datetime.now(ecuador).strftime('%H:%M:%S')
        self.logs.append({"time": ts, "msg": msg, "nivel": nivel})
        if len(self.logs) > 500:
            self.logs = self.logs[-500:]
        try:
            with open("neurotrader_runtime.log", "a", encoding="utf-8") as f:
                f.write(f"{datetime.now(ecuador).isoformat()} [{nivel}] {msg}\n")
        except Exception:
            pass

    def add_debug(self, msg, tipo="INFO", **extra):
        ts = datetime.now(ecuador).strftime('%H:%M:%S')
        evento = {'time': ts, 'tipo': tipo, 'msg': msg}
        evento.update(extra)
        self.diagnostico.setdefault('eventos', []).append(evento)
        self.diagnostico['eventos'] = self.diagnostico['eventos'][-150:]
        if tipo in ('WARN', 'ERROR', 'BLOCK'):
            self.diagnostico['ultimo_bloqueo'] = msg
        elif tipo == 'TRADE':
            self.diagnostico['ultima_ejecucion'] = msg
        else:
            self.diagnostico['estado'] = msg
        try:
            datos = " ".join(f"{k}={v}" for k, v in extra.items()
                             if k not in ("email", "password"))
            with open("neurotrader_runtime.log", "a", encoding="utf-8") as f:
                f.write(f"{datetime.now(ecuador).isoformat()} [DEBUG:{tipo}] {msg} {datos}\n")
        except Exception:
            pass

    def add_trade(self, trade):
        self.trades.append(trade)
        self.stats['total'] += 1
        gano = trade['estado'] == 'GANADA'
        if gano:
            self.stats['ganadas'] += 1
            self.stats['profit'] += trade.get('ganancia', 0)
        elif trade['estado'] == 'PERDIDA':
            self.stats['perdidas'] += 1
            self.stats['profit'] -= trade['monto']
        else:
            self.stats['devueltas'] += 1
        if len(self.trades) > 300:
            self.trades = self.trades[-300:]

    @property
    def win_rate(self):
        cerradas = self.stats['ganadas'] + self.stats['perdidas']
        return (self.stats['ganadas'] / cerradas * 100) if cerradas > 0 else 0.0

    @property
    def current_trade(self):
        return self.active_trades[0] if self.active_trades else None


# ─────────────────────────────────────────────
# OBTENCIÓN DE ACTIVOS
# ─────────────────────────────────────────────

def obtener_activos_disponibles(api, mercado=None):
    """
    Retorna la lista de activos REALES permitidos que están abiertos en IQ Option.
    Los símbolos se normalizan a su nombre base (EURUSD, GBPUSD, etc.)
    """
    try:
        open_time = api.get_all_open_time()
        activos = set()
        if isinstance(open_time, dict):
            for seccion in ('binary', 'turbo'):
                for asset_key, data in open_time.get(seccion, {}).items():
                    if not data.get('open', False):
                        continue
                    simbolo = _limpiar_simbolo(asset_key)
                    if 'OTC' in str(asset_key).upper():
                        continue
                    if simbolo in ACTIVOS_PERMITIDOS:
                        activos.add(simbolo)
        return sorted(activos)
    except Exception as e:
        logger.error(f"Error activos: {e}")
        return []


# ─────────────────────────────────────────────
# OBTENCIÓN DE VELAS CON CACHÉ
# ─────────────────────────────────────────────

_velas_cache: dict = {}
_VELAS_TTL = 4   # segundos — refrescar antes del siguiente ciclo de 5s


def obtener_velas(api, asset: str, n: int = 100, forzar_fresco: bool = False):
    """
    Obtiene velas M1 con caché corto.
    Usa el símbolo limpio (EURUSD, no EURUSD-OP) para get_candles().
    """
    simbolo = _simbolo_candle(asset)
    ahora_ts = time.time()
    if not forzar_fresco:
        cached = _velas_cache.get(simbolo)
        if cached and (ahora_ts - cached[0]) < _VELAS_TTL:
            return cached[1]
    try:
        candles = api.get_candles(simbolo, 60, n, ahora_ts)
        if not candles or len(candles) < 30:
            return None
        df = pd.DataFrame(candles)
        for col in ['open', 'max', 'min', 'close', 'volume']:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        df.dropna(subset=['open', 'close', 'max', 'min'], inplace=True)
        if len(df) < 30:
            return None
        df.rename(columns={'max': 'high', 'min': 'low'}, inplace=True)
        df = df.reset_index(drop=True)
        _velas_cache[simbolo] = (ahora_ts, df)
        return df
    except Exception as e:
        logger.debug(f"get_candles({simbolo}): {e}")
        return None


# ─────────────────────────────────────────────
# CÁLCULO DE INDICADORES TÉCNICOS
# ─────────────────────────────────────────────

def calcular_indicadores(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    close  = df['close'].astype(float)
    high   = df['high'].astype(float)
    low    = df['low'].astype(float)
    volume = df.get('volume', pd.Series(1.0, index=df.index)).astype(float).fillna(1.0)

    # EMA 50
    df['ema50'] = close.ewm(span=50, adjust=False).mean()

    # ATR 14
    tr = pd.concat([
        high - low,
        (high - close.shift(1)).abs(),
        (low  - close.shift(1)).abs()
    ], axis=1).max(axis=1)
    df['atr'] = tr.rolling(14).mean()

    # Stochastic %K / %D (14,3)
    low14  = low.rolling(14).min()
    high14 = high.rolling(14).max()
    rng = (high14 - low14).replace(0, np.nan)
    df['stoch_k'] = ((close - low14) / rng * 100).fillna(50)
    df['stoch_d'] = df['stoch_k'].rolling(3).mean()

    # MFI — Money Flow Index (0-100, como RSI con volumen)
    tp = (high + low + close) / 3
    raw_mf = tp * volume
    pos_mf = raw_mf.where(tp > tp.shift(1), 0.0).fillna(0)
    neg_mf = raw_mf.where(tp < tp.shift(1), 0.0).fillna(0)
    pos14  = pos_mf.rolling(14).sum()
    neg14  = neg_mf.rolling(14).sum()
    mfr    = pos14 / neg14.replace(0, np.nan)
    df['mfi'] = (100 - (100 / (1 + mfr))).fillna(50)

    # MFM per-candle
    hl = (high - low).replace(0, np.nan)
    df['mfm'] = ((close - low) - (high - close)) / hl
    df['mfm'] = df['mfm'].fillna(0)

    return df


# ─────────────────────────────────────────────
# DETECCIÓN DE ZONAS S/R
# ─────────────────────────────────────────────

def _agrupar_niveles(niveles, tolerancia):
    if not niveles:
        return []
    niveles = sorted(float(n) for n in niveles)
    grupos = []
    actual = [niveles[0]]
    for n in niveles[1:]:
        if abs(n - actual[-1]) <= tolerancia:
            actual.append(n)
        else:
            grupos.append(sum(actual) / len(actual))
            actual = [n]
    grupos.append(sum(actual) / len(actual))
    return grupos


def detectar_zona_sr(df: pd.DataFrame, direccion: str):
    """
    Detecta zona S/R con ≥ MIN_TOQUES_SR toques.
    Retorna (en_zona, nivel, num_toques)
    """
    if len(df) < 30:
        return False, None, 0

    u   = df.iloc[-1]
    atr = max(float(u.get('atr', float(u['high']) - float(u['low']))), 1e-9)
    tol_zona   = atr * SR_ATR_TOLERANCIA
    tol_grupo  = max(atr * 0.5, abs(float(u['close'])) * 0.0001, 1e-9)

    seg = df.iloc[-80:-1] if len(df) >= 80 else df.iloc[:-1]

    if direccion == 'CALL':
        vals      = seg['low'].astype(float).tolist()
        swings    = [vals[i] for i in range(1, len(vals) - 1)
                     if vals[i] <= vals[i - 1] and vals[i] <= vals[i + 1]]
        precio_ref = min(float(u['low']), float(u['close']))
    else:
        vals      = seg['high'].astype(float).tolist()
        swings    = [vals[i] for i in range(1, len(vals) - 1)
                     if vals[i] >= vals[i - 1] and vals[i] >= vals[i + 1]]
        precio_ref = max(float(u['high']), float(u['close']))

    niveles = _agrupar_niveles(swings, tol_grupo * 1.8)

    mejor_nivel  = None
    mejor_toques = 0
    for nivel in niveles:
        toques = sum(1 for v in vals if abs(v - nivel) <= tol_grupo * 2)
        if toques >= MIN_TOQUES_SR and abs(precio_ref - nivel) <= tol_zona:
            if toques > mejor_toques:
                mejor_toques = toques
                mejor_nivel  = nivel

    if mejor_nivel is not None:
        return True, mejor_nivel, mejor_toques
    return False, None, 0


# ─────────────────────────────────────────────
# EVALUACIÓN DE SEÑAL PREMIUM
# ─────────────────────────────────────────────

def evaluar_senal_premium(df: pd.DataFrame, asset: str):
    """
    Evalúa señal CALL y PUT bajo los criterios premium.
    S/R es el filtro principal (hard). EMA50 suma puntos pero no bloquea si S/R es fuerte.

    CALL: Soporte ≥2 toques | MFI ≥ 45 | Stoch ≤ 55 | EMA50 (scoring)
    PUT:  Resistencia ≥2 toques | MFI ≤ 55 | Stoch ≥ 45 | EMA50 (scoring)
    """
    if len(df) < 55:
        return None, "datos insuficientes (<55 velas)"

    df = calcular_indicadores(df)
    u = df.iloc[-1]

    close = float(u['close'])
    ema50 = float(u['ema50']) if not pd.isna(u['ema50']) else close
    mfi   = float(u['mfi'])   if not pd.isna(u.get('mfi', np.nan)) else 50.0
    mfm   = float(u['mfm'])
    stk   = float(u['stoch_k'])
    std   = float(u['stoch_d']) if not pd.isna(u.get('stoch_d', np.nan)) else stk

    resultados = []
    razones = {}

    for direccion in ('CALL', 'PUT'):
        score  = 0
        detalle = {}
        motivo_fallo = []

        # ── 1. Zona S/R — FILTRO PRINCIPAL (hard filter) ──────────────────
        en_zona, nivel_sr, num_toques = detectar_zona_sr(df, direccion)
        if not en_zona:
            motivo_fallo.append("sin-SR")
            razones[direccion] = "Sin zona S/R activa (≥2 toques cerca del precio)"
            continue
        pts_sr = min(25 + (num_toques - 2) * 5, 40)
        score += pts_sr
        detalle['sr_toques'] = num_toques
        detalle['nivel_sr']  = nivel_sr

        # ── 2. EMA50 — FILTRO DURO + scoring ─────────────────────────────
        # CALL requiere precio >= EMA50 - banda (soporte en tendencia alcista)
        # PUT  requiere precio <= EMA50 + banda (resistencia en tendencia bajista)
        # Sin esto el bot puede CALL en resistencia o PUT en soporte → PÉRDIDA
        banda = ema50 * EMA50_TOLERANCIA_PCT
        if direccion == 'CALL':
            if close < ema50 - banda:
                # Precio claramente BAJO EMA50 → tendencia bajista → NO operar CALL
                motivo_fallo.append(f"bajo-EMA50")
                razones[direccion] = (
                    f"CALL bloqueado: precio({close:.5f}) está bajo EMA50({ema50:.5f}) "
                    f"— tendencia bajista, solo PUT permitido"
                )
                continue
            # Precio sobre EMA50 (o en banda): calcular bonus por margen
            if close > ema50 + banda:
                margen = (close - ema50) / ema50
                score += min(20 + int(margen * 2000), 25)
            else:
                score += 12   # en la banda de tolerancia: bonus parcial
            detalle['ema50_ok'] = True
            detalle['ema50_val'] = round(ema50, 5)
        else:  # PUT
            if close > ema50 + banda:
                # Precio claramente SOBRE EMA50 → tendencia alcista → NO operar PUT
                motivo_fallo.append(f"sobre-EMA50")
                razones[direccion] = (
                    f"PUT bloqueado: precio({close:.5f}) está sobre EMA50({ema50:.5f}) "
                    f"— tendencia alcista, solo CALL permitido"
                )
                continue
            # Precio bajo EMA50 (o en banda): calcular bonus por margen
            if close < ema50 - banda:
                margen = (ema50 - close) / ema50
                score += min(20 + int(margen * 2000), 25)
            else:
                score += 12
            detalle['ema50_ok'] = True
            detalle['ema50_val'] = round(ema50, 5)

        # ── 3. MFI — Money Flow Index (0-100) ────────────────────────────
        if direccion == 'CALL':
            if mfi < MFI_MINIMO_CALL:
                motivo_fallo.append(f"MFI={mfi:.1f}<{MFI_MINIMO_CALL}")
                razones[direccion] = f"CALL: MFI({mfi:.1f}) < {MFI_MINIMO_CALL} (flujo insuficiente)"
                continue
            pts_mfi = min(15 + int((mfi - MFI_MINIMO_CALL) / 2), 25)
            score += pts_mfi
            detalle['mfi_ok']  = True
            detalle['mfi_val'] = round(mfi, 1)
            detalle['mfm_val'] = round(mfm, 3)
        else:
            if mfi > MFI_MAXIMO_PUT:
                motivo_fallo.append(f"MFI={mfi:.1f}>{MFI_MAXIMO_PUT}")
                razones[direccion] = f"PUT: MFI({mfi:.1f}) > {MFI_MAXIMO_PUT} (flujo insuficiente)"
                continue
            pts_mfi = min(15 + int((MFI_MAXIMO_PUT - mfi) / 2), 25)
            score += pts_mfi
            detalle['mfi_ok']  = True
            detalle['mfi_val'] = round(mfi, 1)
            detalle['mfm_val'] = round(mfm, 3)

        # ── 4. Estocástico apoyando ───────────────────────────────────────
        if direccion == 'CALL':
            if stk > STOCH_SOBREVENTA:
                motivo_fallo.append(f"Stoch={stk:.1f}>{STOCH_SOBREVENTA}")
                razones[direccion] = f"CALL: Stoch({stk:.1f}) > {STOCH_SOBREVENTA} (no en sobreventa)"
                continue
            pts_stoch = min(10 + int((STOCH_SOBREVENTA - stk) / 2), 15)
            score += pts_stoch
            detalle['stoch_ok'] = True
            detalle['stoch_k']  = round(stk, 1)
            prev_k = float(df.iloc[-2]['stoch_k']) if len(df) >= 2 else stk
            prev_d = float(df.iloc[-2]['stoch_d']) if len(df) >= 2 else std
            if stk > std and prev_k <= prev_d:
                score += 5
                detalle['stoch_cruce'] = True
        else:
            if stk < STOCH_SOBRECOMPRA:
                motivo_fallo.append(f"Stoch={stk:.1f}<{STOCH_SOBRECOMPRA}")
                razones[direccion] = f"PUT: Stoch({stk:.1f}) < {STOCH_SOBRECOMPRA} (no en sobrecompra)"
                continue
            pts_stoch = min(10 + int((stk - STOCH_SOBRECOMPRA) / 2), 15)
            score += pts_stoch
            detalle['stoch_ok'] = True
            detalle['stoch_k']  = round(stk, 1)
            prev_k = float(df.iloc[-2]['stoch_k']) if len(df) >= 2 else stk
            prev_d = float(df.iloc[-2]['stoch_d']) if len(df) >= 2 else std
            if stk < std and prev_k >= prev_d:
                score += 5
                detalle['stoch_cruce'] = True

        score = min(score, 100)
        prob  = round(score / 100, 3)

        resultados.append({
            'direccion': direccion,
            'score': score,
            'prob': prob,
            'nivel_sr': nivel_sr,
            'toques_sr': num_toques,
            'detalle': detalle,
            'motivo_fallo': motivo_fallo,
        })

    if not resultados:
        partes = []
        for d, r in razones.items():
            partes.append(r)
        motivo = " | ".join(partes) if partes else "Sin zona S/R válida"
        return None, motivo

    resultados.sort(key=lambda x: -x['score'])
    return resultados[0], "OK"


# ─────────────────────────────────────────────
# VENTANA DE ENTRADA
# ─────────────────────────────────────────────

def en_ventana_entrada() -> bool:
    """Ventana de entrada: segundos 57-03 de cada minuto."""
    seg = datetime.now(ecuador).second
    return seg >= VENTANA_ENTRADA_INICIO_SEG or seg <= VENTANA_ENTRADA_FIN_SEG


def _señales_vigentes(state: BotState) -> list:
    """Filtra señales que no han expirado (< SEÑAL_EXPIRY_SEG segundos)."""
    ahora_ts = time.time()
    if not state.señales_pendientes:
        return []
    edad = ahora_ts - state._señales_ts
    if edad > SEÑAL_EXPIRY_SEG:
        return []
    return state.señales_pendientes


# ─────────────────────────────────────────────
# MOTOR PRINCIPAL DEL BOT
# ─────────────────────────────────────────────

def bot_engine(state: BotState):
    """
    Motor principal con bucle dual:
    - Escaneo de señales: cada PAUSA_ESCANEO_SEG segundos
    - Chequeo de ventana de entrada: cada PAUSA_EJECUCION_SEG (0.5s)

    CORRECCIÓN CRÍTICA: la ventana de entrada se verifica en cada iteración
    corta, independientemente de cuándo terminó el escaneo. Así las señales
    detectadas en el escaneo anterior se ejecutan cuando abre la ventana,
    sin depender de que el timing del escaneo coincida con los segundos 57-03.
    """
    state.add_log("Motor Premium iniciado — operando 24/7 sin horario fijo", "INFO")
    state.add_log(
        f"Activos: {len(ACTIVOS_PERMITIDOS)} pares REAL | "
        f"Escaneo: cada {PAUSA_ESCANEO_SEG}s | Venc: 1 min", "INFO"
    )
    state.add_log(
        f"Condiciones: SR≥{MIN_TOQUES_SR} toques | EMA50(scoring) | "
        f"MFI≥{MFI_MINIMO_CALL}(CALL)/≤{MFI_MAXIMO_PUT}(PUT) | "
        f"Stoch CALL≤{STOCH_SOBREVENTA}/PUT≥{STOCH_SOBRECOMPRA}", "INFO"
    )
    state.add_log(
        f"Ventana entrada: segundos {VENTANA_ENTRADA_INICIO_SEG}-{VENTANA_ENTRADA_FIN_SEG} | "
        f"Score mínimo: {MIN_SCORE_PREMIUM}", "INFO"
    )

    ultimo_scan_ts = 0.0
    en_ventana_prev = False  # para detectar flanco de subida de la ventana

    while state.running:
        try:
            ahora_ts = time.time()
            ahora    = datetime.now(ecuador)

            # ── Verificar operaciones activas ──────────────────────────────
            _verificar_operaciones_activas(state)

            # ── ESCANEO — cada PAUSA_ESCANEO_SEG segundos ─────────────────
            if ahora_ts - ultimo_scan_ts >= PAUSA_ESCANEO_SEG:
                ultimo_scan_ts = ahora_ts

                # Refresh de activos cada 5 minutos
                if ahora_ts - state._ultimo_refresh_activos > 300:
                    if state.api:
                        activos = obtener_activos_disponibles(state.api)
                        if activos:
                            state.activos_disponibles = activos
                        elif not state.activos_disponibles:
                            state.activos_disponibles = sorted(ACTIVOS_PERMITIDOS)
                        state._ultimo_refresh_activos = ahora_ts
                        state.add_log(
                            f"Activos cargados: {len(state.activos_disponibles)} | "
                            + ", ".join(state.activos_disponibles[:5]) + "...", "INFO"
                        )

                activos = state.activos_disponibles or sorted(ACTIVOS_PERMITIDOS)
                state.scan_total = len(activos)

                candidatos  = []
                analisis_log = {}

                state.add_log(
                    f"─── Escaneando {len(activos)} activos [{ahora.strftime('%H:%M:%S')}] ───",
                    "INFO"
                )

                for idx, asset in enumerate(activos):
                    if not state.running:
                        break
                    state.scan_progreso = idx + 1

                    df = obtener_velas(state.api, asset)
                    if df is None or len(df) < 55:
                        motivo = f"Sin datos de velas (recibidas={len(df) if df is not None else 0})"
                        analisis_log[asset] = motivo
                        state.add_log(f"  {asset}: {motivo}", "INFO")
                        continue

                    señal, motivo = evaluar_senal_premium(df, asset)

                    if señal is None:
                        analisis_log[asset] = motivo
                        state.add_log(f"  {asset}: ✗ {motivo}", "INFO")
                        continue

                    if señal['score'] < MIN_SCORE_PREMIUM:
                        motivo = f"Score {señal['score']} < mínimo {MIN_SCORE_PREMIUM}"
                        analisis_log[asset] = motivo
                        state.add_log(
                            f"  {asset}: score bajo ({señal['score']}) — {señal['direccion']} descartado",
                            "INFO"
                        )
                        continue

                    señal['asset'] = asset
                    candidatos.append(señal)
                    analisis_log[asset] = (
                        f"✅ {señal['direccion']} score={señal['score']} "
                        f"prob={señal['prob']:.0%} SR={señal['toques_sr']}toques"
                        + (f" | sin-EMA50" if señal.get('detalle', {}).get('ema50_ok') is False else "")
                    )
                    state.add_log(
                        f"  {asset}: ✅ {señal['direccion']} score={señal['score']} "
                        f"SR={señal['toques_sr']}toques MFI={señal['detalle'].get('mfi_val','?')} "
                        f"Stoch={señal['detalle'].get('stoch_k','?')}",
                        "SIGNAL"
                    )

                state.diagnostico['ultimo_analisis'] = analisis_log

                # Actualizar señales pendientes con timestamp
                if candidatos:
                    state.señales_pendientes = candidatos
                    state._señales_ts = time.time()
                    state._ventana_ejecutada = False  # resetear para la próxima ventana

                    best = max(candidatos, key=lambda x: x['score'])
                    state.diagnostico['mejor_candidato'] = {
                        'asset':     best['asset'],
                        'direccion': best['direccion'],
                        'score':     best['score'],
                        'prob':      best['prob'],
                    }
                    state.señal_actual = best
                    state.add_log(
                        f"  → {len(candidatos)} señal(es) — Mejor: {best['asset']} "
                        f"{best['direccion']} score={best['score']} prob={best['prob']:.0%}",
                        "SIGNAL"
                    )
                else:
                    # No limpiar señales anteriores todavía si no han expirado
                    vigentes = _señales_vigentes(state)
                    if not vigentes:
                        state.señales_pendientes = []
                        state.señal_actual = None
                    state.add_log(
                        f"  → Sin señales nuevas ({len(activos)} activos). "
                        + (f"{len(vigentes)} señal(es) prev. vigentes." if vigentes else ""),
                        "INFO"
                    )

                state.diagnostico['ultimo_lote'] = (
                    f"{len(candidatos)} señal(es) nueva(s) en {len(activos)} activos"
                )

            # ── EJECUCIÓN — revisar ventana cada 0.5 s ────────────────────
            # Se ejecuta INDEPENDIENTEMENTE del escaneo, en cada iteración.
            # Así la señal detectada en el escaneo anterior se ejecuta
            # en cuanto se abra la ventana, sin depender del timing del escaneo.
            en_ventana_ahora = en_ventana_entrada()

            if en_ventana_ahora:
                vigentes = _señales_vigentes(state)
                if vigentes and not state._ventana_ejecutada:
                    ops_libres = MAX_CONCURRENT_TRADES - len(state.active_trades)
                    if ops_libres > 0:
                        # Ordenar por score y recorrer TODOS los candidatos
                        # hasta colocar la operación o agotar la lista
                        candidatos_ord = sorted(vigentes, key=lambda x: -x['score'])
                        # Activos que ya tienen op activa → NO ejecutar de nuevo
                        activos_activos = {t['asset'] for t in state.active_trades}
                        ops_colocadas = 0
                        mejor_score_ejecutado = None
                        for señal in candidatos_ord:
                            if not en_ventana_entrada():
                                state.add_log("Ventana cerrada — operación pendiente cancelada", "WARN")
                                break
                            if ops_colocadas >= ops_libres:
                                break
                            # Bloquear si el activo ya tiene una op activa (evita doble trade)
                            if señal['asset'] in activos_activos:
                                state.add_log(
                                    f"  ⛔ {señal['asset']} ya tiene op activa — saltando",
                                    "WARN"
                                )
                                continue
                            # Para 2ª op: solo si score está muy cerca del mejor ejecutado
                            if ops_colocadas > 0 and mejor_score_ejecutado is not None:
                                if abs(señal['score'] - mejor_score_ejecutado) > UMBRAL_DOBLE_OP:
                                    break
                            ok = _ejecutar_operacion(state, señal)
                            if ok:
                                ops_colocadas += 1
                                activos_activos.add(señal['asset'])
                                mejor_score_ejecutado = señal['score']
                                time.sleep(0.2)
                            else:
                                # Fallo en este activo → intentar el siguiente
                                state.add_log(
                                    f"  → Intentando siguiente candidato...", "WARN"
                                )
                        # Marcar ventana ejecutada (éxito o sin activos disponibles)
                        state._ventana_ejecutada = True
                        if ops_colocadas == 0:
                            state.add_log(
                                "⚠ Ventana cerrada sin éxito — todos los activos rechazados por API",
                                "WARN"
                            )
                    else:
                        state.add_log(
                            f"Ventana abierta pero {MAX_CONCURRENT_TRADES} ops ya activas — esperando",
                            "INFO"
                        )
            else:
                # Al salir de la ventana, resetear para la próxima
                if en_ventana_prev:
                    state._ventana_ejecutada = False

            en_ventana_prev = en_ventana_ahora

        except Exception as e:
            state.add_log(f"Error en motor: {e}", "ERROR")
            logger.exception(f"Error en bot_engine: {e}")

        time.sleep(PAUSA_EJECUCION_SEG)

    state.add_log("Motor detenido.", "INFO")


MAX_TRADE_AGE_SEG   = 75   # forzar cierre a los 75s (1 min vencimiento + 15s margen)
CHECK_WIN_DELAY_SEG = 62   # esperar 62s antes del primer check_win


def _verificar_operaciones_activas(state: BotState):
    """
    Verifica resultado de operaciones activas y las cierra cuando venzan.
    - A los 65s: intenta check_win_v3 / check_win_v4
    - A los 120s: cierre forzado como DESCONOCIDA (evita bloqueo infinito)
    """
    ahora = datetime.now(ecuador)
    cerradas = []

    for trade in list(state.active_trades):
        try:
            entrada_dt = datetime.fromisoformat(
                trade.get('entrada_iso', ahora.isoformat())
            )
            edad_seg = (ahora - entrada_dt).total_seconds()
        except Exception:
            edad_seg = 999  # si no se puede parsear, forzar cierre

        if edad_seg < CHECK_WIN_DELAY_SEG:
            continue  # aún no ha vencido

        id_op = trade.get('id_operacion')

        # ── Cierre forzado si supera MAX_TRADE_AGE ────────────────────────
        if edad_seg >= MAX_TRADE_AGE_SEG:
            if trade['estado'] == 'PENDIENTE':
                trade['estado'] = 'DESCONOCIDA'
                state.add_log(
                    f"⏱ TIMEOUT {trade['asset']} {trade['direccion']} "
                    f"(+{int(edad_seg)}s) — cerrada por tiempo máximo",
                    "WARN"
                )
                try:
                    saldo = state.api.get_balance() if state.api else None
                    if saldo:
                        state.saldo = float(saldo)
                except Exception:
                    pass
                state.add_trade(trade)
                cerradas.append(trade)
            continue

        # ── Consultar resultado normal ─────────────────────────────────────
        if not id_op or not state.api:
            continue

        resultado = None
        try:
            resultado = state.api.check_win_v3(id_op)
        except Exception as e1:
            logger.debug(f"check_win_v3 falló ({e1}), intentando check_win_v4...")
            try:
                resultado = state.api.check_win_v4(id_op)
            except Exception as e2:
                logger.debug(f"check_win_v4 también falló ({e2})")

        # Si la API no devuelve resultado todavía, esperar siguiente ciclo
        if resultado is None:
            state.add_log(
                f"  ⏳ {trade['asset']} {trade['direccion']} "
                f"(+{int(edad_seg)}s) esperando resultado...",
                "INFO"
            )
            continue

        # Procesar resultado
        try:
            resultado_f = float(resultado)
        except (TypeError, ValueError):
            resultado_f = -1.0

        if resultado_f > 0:
            trade['estado']   = 'GANADA'
            trade['ganancia'] = resultado_f
            state.add_log(
                f"✅ WIN {trade['asset']} {trade['direccion']} +${resultado_f:.2f}", "WIN"
            )
        elif resultado_f == 0:
            trade['estado'] = 'DEVUELTA'
            state.add_log(f"↩ DEV {trade['asset']} {trade['direccion']}", "INFO")
        else:
            trade['estado'] = 'PERDIDA'
            state.add_log(
                f"❌ LOSS {trade['asset']} {trade['direccion']} -${trade['monto']:.2f}",
                "LOSS"
            )

        try:
            saldo = state.api.get_balance()
            if saldo:
                state.saldo = float(saldo)
        except Exception:
            pass

        state.add_trade(trade)
        cerradas.append(trade)

    for t in cerradas:
        if t in state.active_trades:
            state.active_trades.remove(t)


def _ejecutar_operacion(state: BotState, señal: dict) -> bool:
    """
    Ejecuta una operación en IQ Option.
    Retorna True si se colocó exitosamente, False si falló.
    """
    ahora  = datetime.now(ecuador)
    asset  = señal['asset']
    dir_op = señal['direccion'].lower()
    monto  = state._calcular_monto()

    if not state.api:
        state.add_log("Sin conexión API — operación cancelada", "WARN")
        return False
    try:
        # Intentar primero como turbo (binary 1 minuto)
        estado_op, id_op = state.api.buy(monto, asset, dir_op, VENCIMIENTO_MINUTOS)

        # Si falla el turbo, intentar con el símbolo OTC como fallback
        if not estado_op:
            asset_otc = asset + "-OTC"
            state.add_log(
                f"  buy({asset}) rechazado, reintentando con {asset_otc}...", "WARN"
            )
            try:
                estado_op, id_op = state.api.buy(monto, asset_otc, dir_op, VENCIMIENTO_MINUTOS)
            except Exception:
                estado_op = False

        if estado_op:
            vence_dt = ahora + timedelta(minutes=VENCIMIENTO_MINUTOS)
            trade = {
                'asset':             asset,
                'direccion':         señal['direccion'],
                'monto':             monto,
                'score':             señal['score'],
                'prob':              señal['prob'],
                'estado':            'PENDIENTE',
                'ganancia':          0.0,
                'entrada':           ahora.strftime('%H:%M:%S'),
                'entrada_iso':       ahora.isoformat(),
                'vencimiento':       vence_dt.strftime('%H:%M:%S'),
                'id_operacion':      id_op,
                'nombre_estrategia': 'S/R Premium',
                'nivel_sr':          señal.get('nivel_sr'),
                'toques_sr':         señal.get('toques_sr', 0),
            }
            state.active_trades.append(trade)
            state.add_log(
                f"🚀 {señal['direccion']} {asset} ${monto:.2f} | "
                f"score={señal['score']} prob={señal['prob']:.0%} | "
                f"SR={señal.get('nivel_sr', 'N/A')} toques={señal.get('toques_sr', 0)}",
                "TRADE"
            )
            state.add_debug(
                f"Operación: {asset} {señal['direccion']} ${monto:.2f} score={señal['score']}",
                tipo="TRADE"
            )
            return True
        else:
            state.add_log(
                f"❌ {asset} rechazado por API (mercado cerrado o no disponible) — saltando",
                "WARN"
            )
            return False
    except Exception as e:
        state.add_log(f"Excepción ejecutando {asset}: {e}", "ERROR")
        logger.exception(f"_ejecutar_operacion: {e}")
        return False
