#!/bin/bash
# NeuroTrader Pro VPS — iniciar bot
pip install -r requirements.txt
pip install git+https://github.com/iqoptionapi/iqoptionapi.git
streamlit run main.py --server.port 5000 --server.address 0.0.0.0
