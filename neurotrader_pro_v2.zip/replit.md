# NeuroTrader Pro

## Project Overview
Python Streamlit trading bot dashboard for IQ Option — Señales Premium, solo mercado REAL.

## Main Files
- `main.py` — Dashboard Streamlit principal con gestión de riesgo y señales premium.
- `bot_engine.py` — Motor de señales: S/R + EMA50 + MFM≥55 + Estocástico + ventana de entrada.
- `pages/1_🔑_Gestor_Licencias.py` — Panel de administración de licencias.
- `licencias.json` — Almacén local de licencias.
- `.streamlit/config.toml` — Configuración del servidor Streamlit (port 5000, 0.0.0.0).
- `requirements.txt` — Dependencias Python.

## Configuración
- **Estrategia única:** S/R Premium (Soporte/Resistencia Fuerte + EMA50 + MFM≥55 + Estocástico)
- **Mercado:** Solo REAL (no OTC)
- **Activos:** EURUSD, GBPUSD, USDJPY, USDCAD, XAUUSD, GBPJPY, EURJPY, AUDUSD, NZDUSD, EURGBP, USDCHF, EURAUD, GBPCAD, AUDJPY
- **Horario:** 08:00 – 11:00 hora Ecuador (America/Guayaquil)
- **Vencimiento:** 1 minuto
- **Gestión de riesgo:** Automático 3% del balance, o Monto Fijo (configurable en UI)
- **Máx. operaciones simultáneas:** 2 (solo si dos señales tienen scores muy similares)
- **Ventana de entrada:** Segundos 58–02 de cada vela
- **Escaneo:** Todos los activos cada 5 segundos

## Señal CALL (Compra)
1. Soporte Fuerte (mínimo 2 toques)
2. Precio > EMA50 M5 (tendencia alcista)
3. MFM ≥ 55% apuntando alcista
4. Estocástico ≤ 30 (sobreventa apoyando rebote)

## Señal PUT (Venta)
1. Resistencia Fuerte (mínimo 2 toques)
2. Precio < EMA50 M5 (tendencia bajista)
3. MFM ≥ 55% apuntando bajista
4. Estocástico ≥ 70 (sobrecompra apoyando caída)

## Replit Setup
- **Language:** Python 3.11
- **Package Manager:** pip
- **Workflow:** `streamlit run main.py` → port 5000 (webview)
- **Streamlit config:** `.streamlit/config.toml` — headless, 0.0.0.0:5000, CORS disabled
- **Deployment target:** vm (always running, needed for persistent bot state)
- **Key dependency:** iqoptionapi (installed from GitHub)
